/*
 * Copyright (c) 2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

//#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <string.h>

#include <linux/dmaengine.h>



#include "sin_dat.h"			// Sinus Werte mit 2 Werten hintereinander




#define max_adr 512 //Addressen des Speichers in der PL




void  ex_restore_sin(int32_t *Array)
{
	int i =0;
    for (i = 0; i < max_adr; i++ )
     {
         Array[i] = sin_dat[i];
     }
  	Array[510]= Array[510] & 0xfffffffe;//damit man im memory-mode bleibt
   // printk("Sinus -> Speicher\n");
}


int main ();

int main()
{
   // printk("Hello World\n");


    //The CMDA variable will hold the mapped address of the CMDA controller
    static void* CDMA = NULL;

    volatile uint32_t* dest = kmalloc(2048, GFP_KERNEL);
    volatile uint32_t* src = kmalloc(2048, GFP_KERNEL);

    ex_restore_sin(int32_t *src);


    //ioremap maps an address range, in this case, 65536 bytes starting at address 0x7E200000, which is the
    //phyical address of the CMDA controller that I've assigned in Vivado.
    CDMA = ioremap(0x7E200000, 65536);

    //iowrite32/ioread32 allows access to read/write from the mapped address range.
    iowrite32(0x04, CDMA + 0x00);    //Writing reset bit
    iowrite32(0x00, CDMA + 0x00);    //Clear reset bit, set simple mode & disable irq







    static dma_addr_t dma_buff = NULL; //Will hold the DMA buffer details
    static void* nDataVirtAddr = NULL; //Will hold the virtual address of the data buffer
    static void* nDataPhysAddr = NULL; //Will hold the physicall address of the data buffer
    int nSize = 0x0800; //Size of desired data buffer

    nDataVirtAddr = kmalloc(nSize, GFP_KERNEL); //Allocate a physically contiguous memory buffer. Returns the virtual address of the buffer
    if(!nDataVirtAddr){  //Checks that the buffer was successfully allocated
    //  printk("CDMA Module : kmalloc failed!\n");
      return -1;
    }

    nDataPhysAddr = virt_to_phys(nDataVirtAddr); //The physical address is needed for the DMA
    nSize = ksize(nDataVirtAddr); //Gets the actual size of the buffer
    dma_buff = dma_map_single(NULL, nDataVirtAddr, nSize, DMA_FROM_DEVICE); //Maps the buffer as a DMA buffer, which seems to handle memory cache issues.
    if(dma_mapping_error(NULL, dma_dest))
    {
   //   printk("CDMA Module: DMA_MAPPING_ERROR\n");
      return -1;
    }

    //Now you can initiate a DMA to nDataPhysAddr here

    iowrite32(virt_to_phys(src), CDMA + 0x18); //Writes source physical addr
  //  iowrite32(virt_to_phys(dest), CDMA + 0x20); //Writes destination physical addr
    iowrite32(0x42000000, CDMA + 0x20); //Writes destination physical addr
    iowrite32(nSize, CDMA + 0x28); //Sets DMA size to 512kB and starts DMA

    while(!(ioread32(CDMA+CDMAStatus) & 0x02))
    {
        //Do nothing until DMA completes
    }


    //Unmap the DMA buffer when done with the DMA
    dma_unmap_single(NULL, dma_dest, nSize, DMA_FROM_DEVICE);





    return 0;
}
